Note of the author!

ENGLISH:
By installing or using this font, you are agree to the Product Usage Agreement:

1. This font for PERSONAL USE. NO COMMERCIAL USE ALLOWED!
2. You are requires a license for PROMOTIONAL or COMMERCIAL use.
3. CONTACT ME before any Promotional or Commercial Use!
>>> blankids.co@gmail.com <<<

LINK TO PURCHASE COMMERSIAL LICENSE:
https://fontbundles.net/blankids

to DONATE click here: Paypal.me/blankids

Thanks,
blankids Studio


INDONESIA:

Dengan meng-install font ini, anda dianggap mengerti dan menyetujui semua syarat dan ketentuan penggunaan font dibawah ini:

1. Font ini hanya dapat digunakan untuk keperluan "Personal Use", atau untuk keperluan yang sifatnya tidak "komersil", alias tidak menghasilkan profit atau keuntungan dari hasil memanfaatkan/menggunakan font saya.

2. DILARANG KERAS menggunakan atau memanfaatkan font ini untuk kepeluan Komersial, baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, atau untuk Kemasan Produk ( baik Fisik ataupun Digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.

3. Menggunakan font ini untuk kepentingan Komersial apapun bentuknya TANPA IZIN dari saya, akan dikenakan biaya EXTENDED LICENSE atau 100 kali lipat dari Lisensi Standard.

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi saya:
Email: blankids.co@gmail.com   
Tlp/WhatsApp: 085740501758

Terima kasih.

